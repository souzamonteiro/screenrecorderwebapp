# [click here for demo](https://raw.githack.com/Meshiest/rnnoise-demo/master/index.html)

### rnnoise-wasm demo

This is a demo using the not at all documented [rnnoise-wasm](https://github.com/jitsi/rnnoise-wasm) dist to determine if input audio is voice. This also demonstrates rendering a simple live frequency chart for audio.
